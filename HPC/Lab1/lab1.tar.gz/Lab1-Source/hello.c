/*
 **  PROGRAM: Hello World
 **
 **  PURPOSE: Standard Hello World program in C
 **
 **  COMPILATION: gcc hello.c -o hello
 **
 **  USAGE: ./hello
 **
 */

#include <stdio.h>
int main ()
{
  printf("Hello World!\n");
}
